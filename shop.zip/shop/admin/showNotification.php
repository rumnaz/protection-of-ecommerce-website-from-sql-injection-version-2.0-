<?php include('../db.php'); ?>
<?php include 'header.php'; ?>
<div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
  		<!--banner-->	
		    <div class="banner">
		   
				<h2>
				<a href="index.php">Home</a>
				<i class="fa fa-angle-right"></i>
				<span>Dashboard</span>
				</h2>
		    </div>
		<!--//banner-->
		<!--content-->
		<div class="content-top">
<?php
 $q = "SELECT * FROM notification";
  $result = mysql_query($q);
    echo "<table>"; // start a table tag in the HTML

while($row = mysql_fetch_array($result)){   //Creates a loop to loop through results
echo "<tr><td>" . $row['data'] . "</td><td>" ;  //$row['index'] the index here is a field name
}

echo "</table>";
?>
                </div>
				 <div class="clearfix"> </div>
				</div>
			</div>
                </div>
       </div>
       </div>

  